export const PluginActionNames = {
    PlayNewMapItemNotificationSound: "PlayNewMapItemNotificationSound"
};