import { CallbackMap, Worker } from "./models";

interface ApiResponse<T> {
  statusCode: number;
  responseObj?: T;
  error?: string;
}

async function callTwilioFunction<T>(
  functionName: string,
  flexAccessToken: string,
  // eslint-disable-next-line @typescript-eslint/ban-types
  requestData?: object,
  skipReadingResponseBody?: boolean
): Promise<ApiResponse<T>> {
  try {
    const searchParams = new URLSearchParams({
      Token: flexAccessToken,
    });

    if (requestData) {
      Object.keys(requestData).forEach((key) => {
        if (Object.prototype.hasOwnProperty.call(requestData, key)) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          searchParams.set(
            `${key[0].toUpperCase()}${key.substring(1)}`,
            (requestData as any)[key]
          );
        }
      });
    }

    const res = await fetch(
      `${process.env.REACT_APP_API_BASE_URL}/${functionName}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: searchParams,
      }
    );

    if (res.ok) {
      try {
        const resData = skipReadingResponseBody
          ? undefined
          : ((await res.json()) as T); //NOTE: not runtime safe
        return {
          statusCode: res.status,
          responseObj: resData,
        };
      } catch (err) {
        console.error(err);
        return {
          statusCode: res.status,
          error: "failed to parse response returned by server",
        };
      }
    } else {
      return {
        statusCode: res.status,
        error: `${res.status} - ${res.statusText || ""}`,
      };
    }
  } catch (err) {
    let errorMessage = "failed to call api";
    if (
      typeof err === "object" &&
      Object.prototype.hasOwnProperty.call(err, "message")
    ) {
      errorMessage = `${errorMessage} - ${err.message}`;
    }
    return {
      statusCode: 0,
      error: errorMessage,
    };
  }
}

export function getSyncToken(
  flexAccessToken: string
): Promise<ApiResponse<{ token: string }>> {
  return callTwilioFunction<{ token: string }>(
    "generatesynctoken",
    flexAccessToken
  );
}

export function getAllCallbackMaps(
  flexAccessToken: string
): Promise<ApiResponse<{ callbackMaps: CallbackMap[] }>> {
  return callTwilioFunction<{ callbackMaps: CallbackMap[] }>(
    "listmaps",
    flexAccessToken
  );
}

export function getWorkerIdentitiesAssignedToCallbackMap(
  flexAccessToken: string,
  mapId: string
): Promise<ApiResponse<{ workerIdentities: string[] }>> {
  return callTwilioFunction<{ workerIdentities: string[] }>(
    "listmapworkers",
    flexAccessToken,
    { mapId }
  );
}

export function addWorkerToCallbackMap(
  flexAccessToken: string,
  workerIdentity: string,
  mapId: string
): Promise<ApiResponse<void>> {
  return callTwilioFunction<void>(
    "updatemapworker",
    flexAccessToken,
    {
      mapId,
      workerIdentity,
      action: "add",
    },
    true
  );
}

export function removeWorkerFromCallbackMap(
  flexAccessToken: string,
  workerIdentity: string,
  mapId: string
): Promise<ApiResponse<void>> {
  return callTwilioFunction<void>(
    "updatemapworker",
    flexAccessToken,
    {
      mapId,
      workerIdentity,
      action: "remove",
    },
    true
  );
}

export async function listWorkers(
  flexAccessToken: string
): Promise<ApiResponse<Worker[]>> {
  const res = await callTwilioFunction<any>("listworkers", flexAccessToken);
  if (res.statusCode === 200) {
    if (res.responseObj?.workers && Array.isArray(res.responseObj.workers)) {
      return {
        statusCode: res.statusCode,
        responseObj: res.responseObj.workers.map((e: any) => new Worker(e)),
      };
    }
    return {
      statusCode: -1,
      error: "failed to parse response from server",
    };
  }
  return res;
}

export function initMapWorker(
  flexAccessToken: string
): Promise<ApiResponse<void>> {
  return callTwilioFunction("initmapworker", flexAccessToken, undefined, true);
}

export function completeCallback(
  flexAccessToken: string,
  mapId: string,
  mapItemId: string,
  toNumberWithCountry: string
): Promise<ApiResponse<void>> {
  return callTwilioFunction(
    "completecallback",
    flexAccessToken,
    {
      mapId,
      mapItemId,
      toNumberWithCountry,
    },
    true
  );
}

export function updateWorkerMapConfig(
  flexAccessToken: string,
  playSoundOnMapItemAdded: boolean
): Promise<ApiResponse<void>> {
  return callTwilioFunction(
    "updatemapworkerconfig",
    flexAccessToken,
    {
      playSoundOnMapItemAdded,
    },
    true
  );
}

export function recycleCallback(
  flexAccessToken: string,
  mapId: string,
  mapItemId: string,
  toNumberWithCountry: string
): Promise<ApiResponse<void>> {
  return callTwilioFunction(
    "recycleCallback",
    flexAccessToken,
    {
      mapId,
      mapItemId,
      toNumberWithCountry,
    },
    true
  );
}
