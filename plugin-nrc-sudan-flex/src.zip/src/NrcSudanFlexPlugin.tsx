import React from "react";
import * as Flex from "@twilio/flex-ui";
import { FlexPlugin } from "flex-plugin";
import { SideLinkForView } from "./components/SideLinkForView";
import SyncClientConnector from "./components/SyncConnector/SyncClientConnector.Container";
import CallbacksTable from "./components/CallbacksTable/CallbacksTable.Container";
import UpdateCallbackStatus from "./components/UpdateCallbackStatus/UpdateCallbackStatusAndHistory.Container";
import CallbackMapWorkerAssignmentTable from "./components/CallbackMapWorkerAssignmentTable/CallbackMapWorkerAssignmentTable.Container";
import WorkerConfigForm from "./components/WorkerConfigForm/WorkerConfigForm.Container";
import reducers, { namespace } from "./states";
import { PluginActionNames } from "./constants";
import RecyclingTable from "./components/RecyclingBin/RecyclingTable.Container";

const PLUGIN_NAME = "NrcSudanFlexPlugin";
const SYNC_NOTIFICATION_ID = "sync-client-notification";
const SYNC_NOTIFICATION_PREFIX = "SyncClient: ";

const reloadWindow = () => {
  if (window && window.location) {
    window.location.reload();
  }
};

export default class NrcSudanFlexPlugin extends FlexPlugin {
  constructor() {
    super(PLUGIN_NAME);
  }

  /**
   * This code is run when your plugin is being started
   * Use this to modify any UI components or attach to the actions framework
   *
   * @param flex { typeof Flex }
   * @param manager { Flex.Manager }
   */
  init(flex: typeof Flex, manager: Flex.Manager) {
    this.registerReducers(manager);

    flex.Notifications.registerNotification({
      id: SYNC_NOTIFICATION_ID,
      content: SYNC_NOTIFICATION_PREFIX,
      closeButton: false,
      type: Flex.NotificationType.error,
      timeout: 0,
      actions: [
        <Flex.NotificationBar.Action
          onClick={() => reloadWindow()}
          label="Reload Page"
        />,
      ],
    });

    const hideSyncNotificationBar = () => {
      flex.Notifications.dismissNotificationById(SYNC_NOTIFICATION_ID);
    };

    const showSyncNotificationBar = (
      type: "warning" | "error",
      message: string
    ) => {
      const item =
        flex.Notifications.registeredNotifications.get(SYNC_NOTIFICATION_ID);
      if (item) {
        item.content = SYNC_NOTIFICATION_PREFIX + message;
        item.type =
          type === "warning"
            ? Flex.NotificationType.warning
            : Flex.NotificationType.error;
        flex.Notifications.showNotification(SYNC_NOTIFICATION_ID);
      }
    };

    flex.RootContainer.Content.remove("header");
    flex.RootContainer.Content.remove("container");
    flex.RootContainer.Content.add(
      <SyncClientConnector
        key="sync-container"
        showNotification={showSyncNotificationBar}
        hideNotification={hideSyncNotificationBar}
      >
        <flex.MainHeader
          key="header"
          {...flex.MainHeader.defaultProps}
        ></flex.MainHeader>
        <flex.MainContainer
          key="container"
          {...flex.MainContainer.defaultProps}
        ></flex.MainContainer>
      </SyncClientConnector>
    );

    // add callbacks to panel 2
    flex.AgentDesktopView.defaultProps.showPanel2 = true;
    flex.AgentDesktopView.Panel2.Content.replace(
      <CallbacksTable key="callback-panel2" />
    );
    flex.AgentDesktopView.Content.add(
      <UpdateCallbackStatus key="update-callback-status" />
    );

    flex.ViewCollection.Content.add(
      <Flex.View name="worker-config-view" key="worker-config-view">
        <WorkerConfigForm />
      </Flex.View>
    );

    flex.SideNav.Content.add(
      <SideLinkForView
        key="worker-config-view-link"
        label="Worker Config"
        icon="Settings"
        iconActive="SettingsBold"
        forViewName="worker-config-view"
      />
    );

    if (
      manager.user.roles.includes("admin") ||
      manager.user.roles.includes("supervisor")
    ) {
      flex.ViewCollection.Content.add(
        <Flex.View
          name="manage-worker-permissions"
          key="manage-worker-permissions-view"
        >
          <CallbackMapWorkerAssignmentTable />
        </Flex.View>
      );

      flex.SideNav.Content.add(
        <SideLinkForView
          key="manage-worker-permissions-link"
          label="Callback Lists User Permissions"
          icon="GroupCall"
          iconActive="GroupCallBold"
          forViewName="manage-worker-permissions"
        />
      );
    }

    flex.AgentDesktopView.defaultProps.splitterOptions = {
      initialFirstPanelSize: "30%",
    };
    flex.AgentDesktopView.Panel1.defaultProps.splitterOrientation =
      Flex.SplitterOrientation.vertical;

    flex.Notifications.registerNotification({
      id: "errorNotification",
      content: "NotificationMessage", // string
      type: Flex.NotificationType.error,
    });

    flex.Actions.registerAction(
      PluginActionNames.PlayNewMapItemNotificationSound,
      () => {
        if (
          (Flex.Manager.getInstance().store.getState().flex as Flex.AppState)
            .phone.connection === undefined
        ) {
          const alertSound = new Audio(
            `${process.env.REACT_APP_API_BASE_URL}/assets/ring.wav`
          );
          return alertSound.play();
        }
        return Promise.resolve();
      }
    );

    flex.ViewCollection.Content.add(
      <Flex.View name="recycling-bin-view" key="recycling-bin-view">
        <RecyclingTable></RecyclingTable>
      </Flex.View>
    );

    flex.SideNav.Content.add(
      <SideLinkForView
        key="recycling-bin-view"
        label="Recycling Bin"
        icon="TasksSmall"
        iconActive="TasksSmall"
        forViewName="recycling-bin-view"
      ></SideLinkForView>
    );
  }

  /**
   * Registers the plugin reducers
   *
   * @param manager { Flex.Manager }
   */
  private registerReducers(manager: Flex.Manager) {
    if (!manager.store.addReducer) {
      // tslint: disable-next-line
      console.error(
        `You need FlexUI > 1.9.0 to use built-in redux; you are currently on ${Flex.VERSION}`
      );
      return;
    }

    manager.store.addReducer(namespace, reducers);
  }
}
