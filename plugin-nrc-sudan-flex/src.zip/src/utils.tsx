import React from "react";
import { Warning } from "@material-ui/icons";
import moment from "moment";

export const delayAsync = (millisecondsToDelay: number): Promise<void> => {
  return new Promise<void>((resolve) => {
    window.setTimeout(() => {
      resolve();
    }, millisecondsToDelay);
  });
};

export const formatDateToLocale = (isoDateString: string): string => {
  try {
    return new Date(isoDateString).toLocaleString(
      navigator.language || "en-US"
    );
  } catch (err) {
    console.error(err);
    return "???";
  }
};

//Prop - date that item received at as a string
//Filter Value - array that contains time range e.g ["This Month"]
//Potential filter values are
// - Today
// - This Week
// - This Month
//If an item is in this range we want to return false
//Otherwise return true
export const filterDateByRange = (prop: string, filterValue: any[]) => {
  //convert props into a moment (switch around the dates) and then get filter value
  const dateRange = filterValue[0];
  const itemDate = moment(prop, "DD-MM-YYYY");
  const now = moment();

  if(dateRange === "Today") {
    //return only results that are from today
    return itemDate.format("YYYY-MM-DD") !== now.format("YYYY-MM-DD");
  }else if(dateRange === "This Week") {
    //return only results that are from within today and 7 days ago inclusive
    const weekAgo = moment().subtract(7, "days");
    return !itemDate.isBetween(weekAgo , now, "dates", "[]");
  }else if (dateRange === "This Month") {
    //return only results from now to 30 days ago
    const monthAgo = moment().subtract(1, "month");
    return !itemDate.isBetween(monthAgo, now, "dates", "[]");
  }

  return false;
}

export const convertPriorityIntoIcon = (priority: string) => {
  if (priority === "Low") {
    return <Warning style={{ color: "green" }} />;
  } else if (priority === "Medium") {
    return <Warning style={{ color: "orange" }} />;
  } else if (priority === "High") {
    return <Warning style={{ color: "red" }} />;
  } else {
    return <Warning />;
  }
};
