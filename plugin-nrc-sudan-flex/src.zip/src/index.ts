import * as FlexPlugin from 'flex-plugin';
import NrcSudanFlexPlugin from './NrcSudanFlexPlugin';

FlexPlugin.loadPlugin(NrcSudanFlexPlugin);
