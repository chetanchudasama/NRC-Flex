import { connect } from 'react-redux';
import { AppState, namespace } from '../../states';
import { getFlexToken } from '../../states/selectors';
import { WorkerConfigForm } from "./WorkerConfigForm";

const mapStateToProps = (state: AppState) => ({
    flexAccessToken: getFlexToken(state),
    playSoundOnMapItemAdded: state[namespace].syncMap.config.playSoundOnMapItemAdded
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(WorkerConfigForm);