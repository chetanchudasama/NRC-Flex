import React from "react";
import Paper from "@material-ui/core/Paper";
import FormLabel from '@material-ui/core/FormLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import { StateToProps } from "./WorkerConfigForm.Container";
import { updateWorkerMapConfig } from "../../api";

type WorkerConfigFormProps = StateToProps;

export const WorkerConfigForm: React.FC<WorkerConfigFormProps> = ({ flexAccessToken, playSoundOnMapItemAdded }) => {
    const updatePlaySoundOnMapItemAdded = async (enable: boolean) => {
        await updateWorkerMapConfig(flexAccessToken, enable);
    }
    return (
        <Paper style={{ padding: "1rem", width: "100%" }}>
            <FormControl>
                <FormLabel>Worker Configuration</FormLabel>
                <FormGroup>
                    <FormControlLabel
                        control={
                            <Switch
                                checked={playSoundOnMapItemAdded}
                                onChange={(_, checked) => updatePlaySoundOnMapItemAdded(checked)}
                                value={playSoundOnMapItemAdded}
                            />
                        }
                        label="Play Sound on Callback Item Received"
                    />
                </FormGroup>
            </FormControl>
        </Paper>
    );
}