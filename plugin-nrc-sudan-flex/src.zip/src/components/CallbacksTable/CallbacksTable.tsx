import React from "react";
import MUIDataTable, { MUIDataTableColumn } from "mui-datatables";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import { StateToProps } from "./CallbacksTable.Container";
import {
  convertPriorityIntoIcon,
  filterDateByRange,
  formatDateToLocale,
} from "../../utils";
import CallbackItemForm from "../CallbackItemForm/CallbackItemForm.Container";
import { CallbackItem } from "models";
import { SyncClientActionsContextProps } from "../SyncConnector/SyncClientActionsContext";

const columns: MUIDataTableColumn[] = [
  {
    name: "initialCallDate",
    label: "Request Received At",
    options: {
      display: "true",
      customBodyRender: (value) => formatDateToLocale(value),
      filter: true,
      filterType: "dropdown",
      customFilterListOptions: { render: (v) => `View Requests From: ${v}` },
      filterOptions: {
        names: ["This Month", "This Week", "Today"],
        logic: filterDateByRange,
      },
    },
  },
  {
    name: "phoneNumber",
    label: "PhoneNumber",
    options: {
      display: "false",
    },
  },
  {
    name: "language",
    label: "Language",
    options: {
      display: "true",
    },
  },
  {
    name: "location",
    label: "Location",
    options: {
      display: "false",
    },
  },
  {
    name: "callerType",
    label: "Caller Type",
    options: {
      display: "true",
    },
  },
  {
    name: "callType",
    label: "Call Type",
    options: {
      display: "true",
    },
  },
  {
    name: "helpOption",
    label: "Help Option",
    options: {
      display: "true",
    },
  },
  {
    name: "priority",
    label: "Priority",
    options: {
      display: "true",
      customBodyRender: (value) => convertPriorityIntoIcon(value),
    },
  },
];

export type CallbacksTableProps = StateToProps & SyncClientActionsContextProps;

type ColumnVisibility = {
  name: string;
  visible: "true" | "false" | "excluded" | undefined;
};

interface CallbacksTableState {
  rowsExpanded: number[];
  visibleColumns: ColumnVisibility[];
}

export class CallbacksTable extends React.PureComponent<
  CallbacksTableProps,
  CallbacksTableState
> {
  readonly state = {
    rowsExpanded: [],
    visibleColumns: columns.map((column) => {
      return {
        name: column.name,
        visible: column.options ? column.options.display : "false",
      };
    }),
  };

  componentDidUpdate(prevProps: CallbacksTableProps) {
    if (this.props.items.length > prevProps.items.length) {
      //items added to table
      const notYetNotified = this.props.items.filter((item) => {
        const notifiedWorkers = item.notifiedWorkers ?? [];
        return !notifiedWorkers.includes(this.props.workerIdentity);
      });

      for (const item of notYetNotified) {
        this.sendNotificationAndUpdate(item);
      }
    }

    if (this.props.items.length < prevProps.items.length) {
      // items removed from table, might need to remove index from rows expanded
      const removedItems = prevProps.items.filter(
        (prevItem) =>
          !this.props.items.find(
            (currentItem) => prevItem.mapItemId === currentItem.mapItemId
          )
      );

      const removedIndexes = removedItems.map((removedItem) =>
        prevProps.items.findIndex(
          (prevItem) => prevItem.mapItemId === removedItem.mapItemId
        )
      );

      this.setState((prevState) => {
        const rowsExpanded = prevState.rowsExpanded;

        removedIndexes.forEach((index) => {
          const expandedIndex = rowsExpanded.findIndex(
            (expandedIndex) => expandedIndex === index
          );
          if (expandedIndex !== -1) {
            rowsExpanded.splice(expandedIndex, 1);
          }
        });

        return {
          rowsExpanded,
        };
      });
    }
  }

  private async sendNotificationAndUpdate(item: CallbackItem) {
    const result = await this.props.syncClientActions?.mutateMapItem(
      item.mapId,
      item.mapItemId,
      (serverValue: any) => {
        const serverItem = serverValue;
        if (!Array.isArray(serverItem.notifiedWorkers)) {
          serverItem.notifiedWorkers = [];
        }
        serverItem.notifiedWorkers.push(this.props.workerIdentity);
        return serverItem;
      }
    );

    console.log({ result });
  }

  private renderExpandableRow = (
    rowData: string[],
    rowMeta: { dataIndex: number }
  ) => {
    const item = this.props.items[rowMeta.dataIndex];
    if (!item) {
      return <TableRow></TableRow>;
    }
    return (
      <TableRow>
        <TableCell colSpan={rowData.length + 1}>
          <CallbackItemForm
            key={`${item.mapId}/${item.mapItemId}`}
            item={item}
          />
        </TableCell>
      </TableRow>
    );
  };

  private onRowsExpand = (current: { dataIndex: number }[]) => {
    if (current && current.length > 0) {
      const dataIndex = current[0].dataIndex;
      this.setState((prevState) => {
        const existingIndex = prevState.rowsExpanded.findIndex(
          (e) => e === dataIndex
        );
        const expandedDataIndexs: number[] = [];
        if (existingIndex === -1) {
          //not already open, open it
          expandedDataIndexs.push(dataIndex);
        } //otherwise it will close
        return {
          ...prevState,
          rowsExpanded: expandedDataIndexs,
        };
      });
    }
  };

  //when we tick show and remove columns we need to keep track of visibilities
  //when state reloads we can then override the defaults with the current state
  private onViewColumnChange = (changedColumn: string, action: string) => {
    console.warn(`COLUMN CHANGE - ${changedColumn} - ${action} `);
    if (action === "add" || action === "remove") {
      //set in state the value of changed columns visibility to be true
      this.setState((prevState) => {
        let newColumnVisibilities = prevState.visibleColumns;
        const colIndex = newColumnVisibilities.findIndex(
          (column) => column.name === changedColumn
        );
        if (colIndex > -1) {
          newColumnVisibilities[colIndex] = {
            name: changedColumn,
            visible: action === "add" ? "true" : "false",
          };
        }

        return { ...prevState, visibleColumns: newColumnVisibilities };
      });
    } else {
      //should never occur - if it does log out what action was
      console.error(action);
    }
  };

  //since we are now keeping track of column visibility in states when component re-renders we need to update columns with the correct visibilities
  private getVisibleColumns = (columns: MUIDataTableColumn[]) => {
    return columns.map((column, index) => {
      return {
        ...column,
        options: {
          ...column.options,
          display: this.state.visibleColumns[index].visible,
        },
      };
    });
  };

  render() {
    return (
      <div style={{ paddingBottom: "2rem" }}>
        <MUIDataTable
          title={"Pending Callbacks"}
          data={this.props.items}
          columns={this.getVisibleColumns(columns)}
          options={{
            filterType: "multiselect",
            selectableRows: "none",
            expandableRows: true,
            expandableRowsOnClick: true,
            onRowsExpand: this.onRowsExpand,
            renderExpandableRow: this.renderExpandableRow,
            rowsExpanded: this.state.rowsExpanded,
            responsive: "scrollFullHeight",
            print: false,
            download: false,
            viewColumns: true,
            onColumnViewChange: this.onViewColumnChange,
          }}
        />
      </div>
    );
  }
}
