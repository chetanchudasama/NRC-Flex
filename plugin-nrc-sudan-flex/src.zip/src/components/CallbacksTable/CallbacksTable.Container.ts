import { connect } from 'react-redux';
import { AppState } from '../../states';
import { getActiveCallbackItems, getWorkerIdentity } from '../../states/selectors';
import { CallbacksTableStyled } from "./CallbacksTable.Styled";
import { withSyncClientActionsContext } from "../SyncConnector/SyncClientActionsContext";

const mapStateToProps = (state: AppState) => ({
	items: getActiveCallbackItems(state),
    workerIdentity: getWorkerIdentity(state),
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(withSyncClientActionsContext(CallbacksTableStyled));