import { MuiThemeProvider, createMuiTheme } from "@material-ui/core";
import React from "react";
import { CallbacksTable, CallbacksTableProps } from "./CallbacksTable"

const theme = createMuiTheme({
	typography: {
		useNextVariants: true,
	},
	overrides: {
		MuiTableCell: {
			root: {
				fontSize: "30rem"
			}
		}
	}
});

export const CallbacksTableStyled: React.FC<CallbacksTableProps> = (props) => {
	return (
		<MuiThemeProvider theme={theme}>
			<CallbacksTable {...props} />
		</MuiThemeProvider>
	);
}