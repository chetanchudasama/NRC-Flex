import React from "react";
import { Actions, SideLink } from "@twilio/flex-ui";

interface SideLinkForViewProps {
    forViewName: string;
    label: string;
    icon: string;
    iconActive: string;
    activeView?: string;
}

export const SideLinkForView: React.FC<SideLinkForViewProps> = ({ forViewName, label, activeView, icon, iconActive }) => {
    const goToView = () => {
        Actions.invokeAction("NavigateToView", { viewName: forViewName });
    };
    return (
        <SideLink
            showLabel={true}
            icon={icon}
            iconActive={iconActive}
            isActive={activeView === forViewName}
            onClick={goToView}
        >
            {label}
        </SideLink>
    );
};
