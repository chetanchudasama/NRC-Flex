import { MuiThemeProvider, createMuiTheme } from "@material-ui/core";
import React from "react";
import { RecyclingTable, RecyclingTableProps } from "./RecyclingTable"

const theme = createMuiTheme({
	typography: {
		useNextVariants: true,
	},
	overrides: {
		MuiTableCell: {
			root: {
				fontSize: "30rem"
			}
		}
	}
});

export const RecyclingTableStyled: React.FC<RecyclingTableProps> = (props) => {
	return (
		<MuiThemeProvider theme={theme}>
			<RecyclingTable {...props} />
		</MuiThemeProvider>
	);
}