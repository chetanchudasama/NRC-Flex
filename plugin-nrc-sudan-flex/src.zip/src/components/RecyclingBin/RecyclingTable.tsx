import React from "react";
import { IconButton } from "@twilio/flex-ui";
import { Warning } from "@material-ui/icons";
import MUIDataTable, { MUIDataTableColumn } from "mui-datatables";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import { StateToProps } from "./RecyclingTable.Container";
import { formatDateToLocale } from "../../utils";
import RecyclingTableItemForm from "../RecyclingTableItem/RecyclingTableItemForm.Container";
import { CallbackItem } from "models";
import { SyncClientActionsContextProps } from "../SyncConnector/SyncClientActionsContext";
import { RecycleIcon } from "../RecycleIcon";
import { recycleCallback } from "../../api";

const columns: MUIDataTableColumn[] = [
  {
    name: "initialCallDate",
    label: "Request Received At",
    options: {
      display: "true",
      customBodyRender: (value) => formatDateToLocale(value),
    },
  },
  {
    name: "phoneNumber",
    label: "PhoneNumber",
    options: {
      display: "false",
    },
  },
  {
    name: "language",
    label: "Language",
    options: {
      display: "true",
    },
  },
  {
    name: "location",
    label: "Location",
    options: {
      display: "false",
    },
  },
  {
    name: "callerType",
    label: "Caller Type",
    options: {
      display: "true",
    },
  },
  {
    name: "callType",
    label: "Call Type",
    options: {
      display: "true",
    },
  },
  {
    name: "helpOption",
    label: "Help Option",
    options: {
      display: "true",
    },
  },
  {
    name: "priority",
    label: "Priority",
    options: {
      display: "true",
      customBodyRender: (value) => convertPriorityIntoIcon(value),
    },
  },
];

const convertPriorityIntoIcon = (priority: string) => {
  if (priority === "Low") {
    return <Warning style={{ color: "green" }} />;
  } else if (priority === "Medium") {
    return <Warning style={{ color: "orange" }} />;
  } else if (priority === "High") {
    return <Warning style={{ color: "red" }} />;
  } else {
    return <Warning />;
  }
};

export type RecyclingTableProps = StateToProps & SyncClientActionsContextProps;

interface CallbacksTableState {
  rowsExpanded: number[];
  rowsSelected: number[];
  selected: boolean;
  rowCount: number;
}

export class RecyclingTable extends React.PureComponent<
  RecyclingTableProps,
  CallbacksTableState
> {
  readonly state = {
    rowsExpanded: [],
    rowsSelected: [],
    selected: false,
    rowCount: 0,
  };

  componentDidUpdate(prevProps: RecyclingTableProps) {
    if (this.props.items.length > prevProps.items.length) {
      const notYetNotified = this.props.items.filter((item) => {
        const notifiedWorkers = item.notifiedWorkers ?? [];
        return !notifiedWorkers.includes(this.props.workerIdentity);
      });

      for (const item of notYetNotified) {
        this.sendNotificationAndUpdate(item);
      }
    }

    if (this.props.items.length < prevProps.items.length) {
      // items removed from table, might need to remove index from rows expanded
      const removedItems = prevProps.items.filter(
        (prevItem) =>
          !this.props.items.find(
            (currentItem) => prevItem.mapItemId === currentItem.mapItemId
          )
      );

      const removedIndexes = removedItems.map((removedItem) =>
        prevProps.items.findIndex(
          (prevItem) => prevItem.mapItemId === removedItem.mapItemId
        )
      );

      this.setState((prevState) => {
        const rowsExpanded = prevState.rowsExpanded;

        removedIndexes.forEach((index) => {
          const expandedIndex = rowsExpanded.findIndex(
            (expandedIndex) => expandedIndex === index
          );
          if (expandedIndex !== -1) {
            rowsExpanded.splice(expandedIndex, 1);
          }
        });

        return {
          rowsExpanded,
        };
      });
    }
  }

  private async sendNotificationAndUpdate(item: CallbackItem) {
    const result = await this.props.syncClientActions?.mutateMapItem(
      item.mapId,
      item.mapItemId,
      (serverValue: any) => {
        const serverItem = serverValue;
        if (!Array.isArray(serverItem.notifiedWorkers)) {
          serverItem.notifiedWorkers = [];
        }
        serverItem.notifiedWorkers.push(this.props.workerIdentity);
        return serverItem;
      }
    );

    console.log({ result });
  }

  private renderExpandableRow = (
    rowData: string[],
    rowMeta: { dataIndex: number }
  ) => {
    const item = this.props.items[rowMeta.dataIndex];
    if (!item) {
      return <TableRow></TableRow>;
    }
    return (
      <TableRow>
        <TableCell colSpan={rowData.length + 1}>
          <RecyclingTableItemForm
            key={`${item.mapId}/${item.mapItemId}`}
            item={item}
          />
        </TableCell>
      </TableRow>
    );
  };

  private onRowsExpand = (current: { dataIndex: number }[]) => {
    if (current && current.length > 0) {
      const dataIndex = current[0].dataIndex;
      this.setState((prevState) => {
        const existingIndex = prevState.rowsExpanded.findIndex(
          (e) => e === dataIndex
        );
        const expandedDataIndexs: number[] = [];
        if (existingIndex === -1) {
          //not already open, open it
          expandedDataIndexs.push(dataIndex);
        } //otherwise it will close
        return {
          ...prevState,
          rowsExpanded: expandedDataIndexs,
        };
      });
    }
  };

  private onRowSelect = (currentRowsSelected: { dataIndex: number }[]) => {

  };

  private renderToolbarSelect = (selectedRows: {
    data: { index: number; dataIndex: number }[];
  }) => {
    return (
      <div style={{ float: "right", marginTop: "0.75rem", padding: "1rem" }}>
        <IconButton
          title="Recycle Callback Item"
          icon={<RecycleIcon />}
          onClick={() => this.recycleItem(selectedRows)}
        />
      </div>
    );
  };

  private recycleItem = (selectedRows: {
    data: { index: number; dataIndex: number }[];
  }) => {
    selectedRows.data.forEach(async (item) => {
      await recycleCallback(
        this.props.flexAccessToken,
        this.props.items[item.dataIndex].mapId,
        this.props.items[item.dataIndex].mapItemId,
        this.props.items[item.dataIndex].phoneNumber
      );
    });
    this.setState({
      rowsSelected: [],
    });
  };

  render() {
    return (
      <div style={{ paddingBottom: "2rem", width: "100%", zIndex: 0 }}>
        <MUIDataTable
          title={"Recycling Bin"}
          data={this.props.items}
          columns={columns}
          options={{
            filterType: "multiselect",
            selectableRows: "multiple",
            rowsSelected: this.state.rowsSelected,
            onRowsSelect: this.onRowSelect,
            customToolbarSelect: this.renderToolbarSelect,
            expandableRows: true,
            expandableRowsOnClick: true,
            onRowsExpand: this.onRowsExpand,
            renderExpandableRow: this.renderExpandableRow,
            rowsExpanded: this.state.rowsExpanded,
            responsive: "scrollFullHeight",
            print: false,
            download: false,
            viewColumns: false,
          }}
        />
      </div>
    );
  }
}
