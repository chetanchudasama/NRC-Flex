import { connect } from 'react-redux';
import { AppState } from '../../states';
import { getCompleteCallbackItems, getFlexToken, getWorkerIdentity } from '../../states/selectors';
import { RecyclingTableStyled } from "./RecyclingTable.Styled";
import { withSyncClientActionsContext } from "../SyncConnector/SyncClientActionsContext";

const mapStateToProps = (state: AppState) => ({
	items: getCompleteCallbackItems(state),
    workerIdentity: getWorkerIdentity(state),
    flexAccessToken: getFlexToken(state)
});

export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(withSyncClientActionsContext(RecyclingTableStyled));