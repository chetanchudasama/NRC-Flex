import React from "react";
import { IconButton } from "@twilio/flex-ui";
import Typography from '@material-ui/core/Typography';
import TableRow from "@material-ui/core/TableRow";
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import { StateToProps } from "./CallbackMapWorkerAssignmentTable.Container";
import { getAllCallbackMaps, listWorkers, getWorkerIdentitiesAssignedToCallbackMap, removeWorkerFromCallbackMap } from "../../api";
import { CallbackMap, Worker } from "../../models";
import { BinIcon } from "../BinIcon";
import { AddWorkerToMapDialog } from "./AddWorkerToMapDialog";
import { PaperStyled, TabledStyled, TableCellStyled, SelectStyled } from "./StyledComponents";

type CallbackMapWorkerAssignmentTableProps = StateToProps;

interface CallbackMapWorkerAssignmentTableState {
	allMaps: CallbackMap[];
	allWorkers: Worker[];
	displayForMapId: string;
	assignedWorkers: { identity: string, name: string, email: string }[];
	status: 'loading-maps' | 'loading-workers' | 'loaded' | 'saving-changes' | 'show-add-agent-dialog' | 'error';
	error?: string;
}

export class CallbackMapWorkerAssignmentTable extends React.PureComponent<
	CallbackMapWorkerAssignmentTableProps, CallbackMapWorkerAssignmentTableState> {
	private mounted: boolean = false;
	readonly state: Readonly<CallbackMapWorkerAssignmentTableState> = {
		allMaps: [],
		allWorkers: [],
		displayForMapId: "",
		assignedWorkers: [],
		status: "loading-maps"
	};

	async componentDidMount() {
		this.mounted = true;
		try {
			const res = await getAllCallbackMaps(this.props.flexToken);
			if (!this.mounted) {
				return;
			}
			if (res.statusCode === 200 && res.responseObj?.callbackMaps && res.responseObj.callbackMaps.length > 0) {
				this.setState({
					allMaps: res.responseObj.callbackMaps
				});
			} else {
				this.setState({
					status: "error",
					error: "no callback maps returned by API, please refresh the page to try again"
				});
				return;
			}
		} catch (err) {
			console.error("failed to getAllCallbackMaps");
			console.error(err);
			if (this.mounted) {
				this.setState({
					status: "error",
					error: "failed to call API to get list of all callback maps, please refresh the page to try again"
				});
			}
			return;
		}

		try {
			const res = await listWorkers(this.props.flexToken);
			if (!this.mounted) {
				return;
			}
			if (res.statusCode === 200 && res.responseObj && res.responseObj.length > 0) {
				this.setState({
					status: "loaded",
					allWorkers: res.responseObj
				});
			} else {
				this.setState({
					status: "error",
					error: "no workers returned by API, please refresh the page to try again"
				});
			}
		} catch (err) {
			console.error("failed to listWorkers");
			console.error(err);
			if (this.mounted) {
				this.setState({
					status: "error",
					error: "failed to call API to get list of all workers, please refresh the page to try again"
				});
			}
		}
	}

	componentDidUpdate(_: CallbackMapWorkerAssignmentTableProps, prevState: CallbackMapWorkerAssignmentTableState) {
		if (this.state.displayForMapId !== prevState.displayForMapId) {
			this.loadWorkers(this.state.displayForMapId);
		}
	}

	componentWillUnmount() {
		this.mounted = false;
	}

	private loadWorkers = async (mapId: string) => {
		this.setState({ status: "loading-workers" });
		try {
			const res = mapId ? (await getWorkerIdentitiesAssignedToCallbackMap(this.props.flexToken, mapId)) : {
				statusCode: 200,
				responseObj: { workerIdentities: [] }
			};
			if (!this.mounted) {
				return;
			}
			this.setState((prevState) => {
				if (prevState.displayForMapId !== mapId) {
					//mapId changed, skip load
					return prevState;
				}
				if (res.statusCode !== 200) {
					return {
						...prevState,
						status: "error",
						error: "failed to load workers, response code was: {}. please refresh the page to try again"
					};
				}

				return {
					...prevState,
					status: "loaded",
					assignedWorkers: (res.responseObj?.workerIdentities || []).map(workerIdentity => ({
						identity: workerIdentity,
						name: prevState.allWorkers.find(e => e.identity === workerIdentity)?.name || "",
						email: prevState.allWorkers.find(e => e.identity === workerIdentity)?.email || "",
					}))
				};
			});
		} catch (err) {
			console.error("failed to getWorkerIdentitiesAssignedToCallbackMap");
			console.error(err);
			if (this.mounted) {
				this.setState({
					status: "error",
					error: "failed to load workers for selected map, please refresh the page to try again"
				});
			}
		}
	}

	private removeWorker = async (workerIdentity: string) => {
		if (this.state.displayForMapId) {
			this.setState({ status: "saving-changes" });
			const mapId = this.state.displayForMapId;
			try {
				await removeWorkerFromCallbackMap(this.props.flexToken, workerIdentity, mapId);
				if (!this.mounted) {
					return;
				}
				this.loadWorkers(mapId);
			} catch (err) {
				if (this.mounted) {
					this.setState({
						status: "error",
						error: "failed to remove worker"
					});
				}
			}
		}
	}

	private addWorker = async () => {
		if (this.state.displayForMapId) {
			this.setState({ status: "show-add-agent-dialog" });
		}
	}

	private shouldDisableActions = () => this.state.status === "saving-changes" || this.state.status === "show-add-agent-dialog";

	render() {
		return (
			<PaperStyled>
				{this.state.status === "show-add-agent-dialog" ? <AddWorkerToMapDialog
					flexToken={this.props.flexToken}
					mapId={this.state.displayForMapId}
					options={this.state.allWorkers.filter(e => this.state.assignedWorkers.findIndex(i => i.identity === e.identity) === -1)}
					onCancel={() => this.setState({ status: "loaded" })}
					onSuccess={() => this.loadWorkers(this.state.displayForMapId)}
				/> : null}
				{this.state.status !== "loading-maps" && this.state.allMaps.length > 0 ? (
					<div>
						<SelectStyled
							variant="filled"
							value={this.state.displayForMapId}
							onChange={e => this.setState({ displayForMapId: e.target.value })}>
							<MenuItem value=""></MenuItem>
							{this.state.allMaps.map(e => <MenuItem key={e.uniqueName} value={e.uniqueName}>{e.friendlyName || e.uniqueName}</MenuItem>)}
						</SelectStyled>
						{this.state.displayForMapId ? <Button variant="outlined" disabled={this.shouldDisableActions()} onClick={() => this.addWorker()}>Add</Button> : null}
					</div>
				) : null}
				{this.state.status === "loaded" || this.state.status === "saving-changes" ||
					this.state.status === "loading-workers" || this.state.status === "show-add-agent-dialog" ? (
						<TabledStyled>
							<TableHead>
								<TableRow>
									<TableCellStyled scope="col">Name</TableCellStyled>
									<TableCellStyled scope="col">Email</TableCellStyled>
									<TableCellStyled scope="col">Actions</TableCellStyled>
								</TableRow>
							</TableHead>
							<TableBody>
								{this.state.status === "loading-workers" ? <TableRow><TableCellStyled colSpan={3}>Loading workers, please wait ...</TableCellStyled></TableRow> :
									!this.state.displayForMapId ? <TableRow><TableCellStyled colSpan={3}>Please select an item from the dropdown to view the workers with permission to view that callbacks list.</TableCellStyled></TableRow> :
										this.state.assignedWorkers.length === 0 ? <TableRow><TableCellStyled colSpan={3}>No workers currently assigned, please use the Add button to add one.</TableCellStyled></TableRow>
											: this.state.assignedWorkers.map((item) => (
												<TableRow key={`${this.state.displayForMapId}/${item.identity}`}>
													<TableCellStyled>{item.name}</TableCellStyled>
													<TableCellStyled>{item.email}</TableCellStyled>
													<TableCellStyled>
														<IconButton disabled={this.shouldDisableActions()} icon={<BinIcon />} onClick={() => this.removeWorker(item.identity)} />
													</TableCellStyled>
												</TableRow>
											))}
							</TableBody>
						</TabledStyled>)
					: (
						<Typography component="p">{this.state.status === "error" ? `Error: ${this.state.error || "an unexpected error occoured"}` :
							this.state.status === "loading-maps" ? "loading please wait ..." : "ERROR: unknowwn status!"}</Typography>
					)}
			</PaperStyled>
		);
	}
}