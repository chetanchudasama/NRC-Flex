import React from 'react';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Dialog from '@material-ui/core/Dialog';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import {Worker} from "../../models";
import {addWorkerToCallbackMap} from "../../api";

interface AddWorkerToMapDialogProps {
	flexToken: string;
	mapId: string;
	options: Worker[];
	onCancel: () => void;
	onSuccess: () => void;
}

interface  AddWorkerToMapDialogState {
	selectedWorkerIdentity?: string;
	disableForm: boolean;
}

export class AddWorkerToMapDialog extends React.Component<AddWorkerToMapDialogProps, AddWorkerToMapDialogState> {
	
	readonly state = {
		disableForm: false,
		selectedWorkerIdentity: undefined
	};

	private handleCancel = () => {
		this.props.onCancel();
	};

	private handleOk = async () => {
		const workerIdentity = this.state.selectedWorkerIdentity;
		if(workerIdentity){
			this.setState({disableForm: true});
			try{
				await addWorkerToCallbackMap(this.props.flexToken, workerIdentity, this.props.mapId);
			}catch(err){
				console.error("failed to addWorkerToCallbackMap");
				console.error(err);
			}
			this.props.onSuccess();
			return;
		}
		this.props.onCancel();
	};

	private handleChange = (_: unknown, value: string) => {
		this.setState({selectedWorkerIdentity: value});
	};

	render() {
		return (
			<Dialog
				disableBackdropClick
				disableEscapeKeyDown
				maxWidth="sm"
				open={true}
			>
				<DialogTitle id="confirmation-dialog-title">
					Select Worker
				</DialogTitle>
				<DialogContent>
					<RadioGroup
						name="worker"
						value={this.state.selectedWorkerIdentity}
						onChange={this.handleChange}
					>
						{this.props.options.map(option => (
						<FormControlLabel disabled={this.state.disableForm} value={option.identity} key={option.identity} control={<Radio />} label={option.name} />
						))}
					</RadioGroup>
				</DialogContent>
				<DialogActions>
					<Button disabled={this.state.disableForm} onClick={this.handleCancel} color="secondary">
						Cancel
					</Button>
					<Button disabled={this.state.disableForm} onClick={this.handleOk} color="primary">
						Add
					</Button>
				</DialogActions>
			</Dialog>
		);
	}
}