import { connect } from 'react-redux';
import { AppState } from '../../states';
import { getFlexToken } from "../../states/selectors";
import { CallbackMapWorkerAssignmentTable } from "./CallbackMapWorkerAssignmentTable";

const mapStateToProps = (state: AppState) => ({
	flexToken: getFlexToken(state)
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(CallbackMapWorkerAssignmentTable);