import styled from "react-emotion";
import Table from "@material-ui/core/Table";
import TableCell from "@material-ui/core/TableCell";
import Paper from "@material-ui/core/Paper";
import Select from "@material-ui/core/Select";

export const TabledStyled = styled(Table)({
    marginTop: "1rem",
    fontSize: "12px"
});

export const TableCellStyled = styled(TableCell)({
    fontSize: "12px !important"
});

export const PaperStyled = styled(Paper)({
    padding: "1rem",
    width: "100%"
});

export const SelectStyled = styled(Select)({
    minWidth: "160px",
    marginRight: "1rem"
})