import React from "react";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

interface SelectControlProps {
    fieldId: string,
    label: string;
    value: string,
    onChange: (value: string) => void;
    options: string[];
    addEmptyToTop?: boolean;
}

export const SelectControl: React.FC<SelectControlProps> = ({ fieldId, label, value, onChange, options, addEmptyToTop }) => {
    return (
        <FormControl style={{ width: "100%", margin: "1rem" }}>
            <InputLabel shrink={true} htmlFor={fieldId}>{label}</InputLabel>
            <Select
                value={value}
                variant="outlined"
                onChange={(e) => onChange(e.target.value)}
                inputProps={{
                    id: fieldId
                }}
            >
                {addEmptyToTop ? <MenuItem key="__EMPTY__" value=""></MenuItem> : null}
                {options.map(o =>
                    <MenuItem key={o} value={o}>{o}</MenuItem>)}
            </Select>
        </FormControl>
    );
}