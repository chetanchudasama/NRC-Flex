import React from "react";
import { TaskContextProps } from "@twilio/flex-ui";
import { StateToProps } from "./UpdateCallbackStatusAndHistory.Container";
import { OutboundCallTaskInfo, getOutboundCallTaskInfoWithHash, convertToCallbackItem } from "../../models";
import { SyncClientActionsContextProps } from "../SyncConnector/SyncClientActionsContext";

export type UpdateCallbackStatusAndHistoryProps = StateToProps & TaskContextProps & SyncClientActionsContextProps;
export type test = UpdateCallbackStatusAndHistoryProps & object;

interface UpdateCallbackStatusAndHistoryState {
	outboundCallTasksWithHash: { hash: string, item: OutboundCallTaskInfo }[]
}

export class UpdateCallbackStatusAndHistory extends React.Component<UpdateCallbackStatusAndHistoryProps, UpdateCallbackStatusAndHistoryState> {
	readonly state: UpdateCallbackStatusAndHistoryState = {
		outboundCallTasksWithHash: []
	}

	async componentDidMount() {
		await this.checkStatus();
	}

	async componentDidUpdate() {
		await this.checkStatus();
	}

	private checkStatus = async (): Promise<void> => {
		console.log(`${new Date().toISOString()} IN CHECK STATUS`);
		const taskInfoWithHash = getOutboundCallTaskInfoWithHash(this.props.workerIdentity, this.props.workerName, this.props.task, this.props.conference);
		if (taskInfoWithHash) {
			console.log("HAVE OUTBOUND VOICE TASK");
			const newItem = {
				hash: taskInfoWithHash[0],
				item: taskInfoWithHash[1]
			};

			const mapId = this.props.task?.attributes?.mapId;
			if (!mapId) {
				console.log("mapId MISSING FROM TASK ATTRIBUTES - SKIPPING");
			}

			const mapItemId = this.props.task?.attributes?.mapItemId;
			if (!mapItemId) {
				console.log("mapItemId MISSING FROM TASK ATTRIBUTES - SKIPPING");
			}

			const existingItem = this.state.outboundCallTasksWithHash.find(e => e.item.taskSid === newItem.item.taskSid);
			if (existingItem && existingItem.hash === newItem.hash) {
				console.log("HASH MATCHES EXISTING STATE - SKIPPING");
				return;
			}

			console.log("NEW ITEM DIFFERENT FROM STATE (UDATATE STATE)");
			this.setState(prevState => {
				const prevStateExistingIndex = prevState.outboundCallTasksWithHash.findIndex(e => e.item.taskSid === newItem.item.taskSid);
				const newItems = [...prevState.outboundCallTasksWithHash];
				if (prevStateExistingIndex === -1) {
					newItems.push(newItem);
				} else {
					newItems.splice(prevStateExistingIndex, 1, newItem);
				}
				return { outboundCallTasksWithHash: newItems };
			});

			console.log("NEW ITEM DIFFERENT FROM STATE (MUTUATE SYNC ITEMS)");
			await this.props.syncClientActions?.mutateMapItem(mapId, mapItemId, (remoteValue) => {
				const remoteItem = convertToCallbackItem(mapId, mapItemId, remoteValue);
				if (!remoteItem.callbackHistory) {
					remoteItem.callbackHistory = [];
				}
				const existingIndex = remoteItem.callbackHistory.findIndex(e => e.taskSid === newItem.item.taskSid);
				if (existingIndex === -1) {
					remoteItem.callbackHistory.push(newItem.item);
				} else {
					remoteItem.callbackHistory.splice(existingIndex, 1, newItem.item);
				}
				return remoteItem;
			});
		}
		console.log(`${new Date().toISOString()} CHECK STATUS DONE`);
	};

	render() {
		return null; //non-visual component
	}
};