import { ComponentType } from "react";
import { connect } from 'react-redux';
import { withTaskContext } from "@twilio/flex-ui";
import { AppState } from '../../states';
import { getWorkerIdentity, getWorkerName } from '../../states/selectors';
import { withSyncClientActionsContext } from "../SyncConnector/SyncClientActionsContext";
import { UpdateCallbackStatusAndHistory, UpdateCallbackStatusAndHistoryProps } from './UpdateCallbackStatusAndHistory';

const mapStateToProps = (state: AppState) => ({
	workerIdentity: getWorkerIdentity(state),
	workerName: getWorkerName(state)
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(
	withSyncClientActionsContext(
		withTaskContext<
			UpdateCallbackStatusAndHistoryProps,
			ComponentType<UpdateCallbackStatusAndHistoryProps>
		>(UpdateCallbackStatusAndHistory)));