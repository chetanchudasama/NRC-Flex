import { connect } from "react-redux";
import { AppState } from "../../states";
import { PriorityDropDown, PriorityDropDownOwnProps } from "./PriorityDropDown";
import { withSyncClientActionsContext } from "../SyncConnector/SyncClientActionsContext";

const mapStateToProps = (
  state: AppState,
  props: PriorityDropDownOwnProps
) => ({});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(
  withSyncClientActionsContext(PriorityDropDown)
);
