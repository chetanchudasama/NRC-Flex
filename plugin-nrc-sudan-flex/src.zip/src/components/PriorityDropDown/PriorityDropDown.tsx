import React from "react";
import { CallbackItem } from "../../models";
import { StateToProps } from "./PriorityDropDown.Container";
import { SyncClientActionsContextProps } from "../SyncConnector/SyncClientActionsContext";
import {
  FormControl,
  InputLabel,
  ListItemText,
  MenuItem,
  Select,
} from "@material-ui/core";
import { Warning } from "@material-ui/icons";

export interface PriorityDropDownOwnProps {
  item: CallbackItem;
}

type PriorityDropDownProps = StateToProps &
  PriorityDropDownOwnProps &
  SyncClientActionsContextProps;

export class PriorityDropDown extends React.PureComponent<PriorityDropDownProps> {
  private handlePriorityChange = async (event: any) => {
    console.warn(event);
    await this.props.syncClientActions?.mutateMapItem(
      this.props.item.mapId,
      this.props.item.mapItemId,
      (serverValue: any) => {
        const serverItem = serverValue;

        serverItem.priority = event.target.value;

        return serverItem;
      }
    );
  };

  render() {
    return (
      <FormControl>
        <InputLabel>Priority</InputLabel>
        <Select
          id="demo-simple-select"
          value={this.props.item.priority}
          onChange={this.handlePriorityChange}
          style={{ marginTop: 10.5 }}
        >
          <MenuItem value={"Low"}>
            <div style={{ display: "flex", alignItems: "center" }}>
              <Warning style={{ color: "green" }} />
              <ListItemText primary="Low Priority" />
            </div>
          </MenuItem>
          <MenuItem value={"Medium"}>
            <div style={{ display: "flex", alignItems: "center" }}>
              <Warning style={{ color: "orange" }} />
              <ListItemText primary="Medium Priority" />
            </div>
          </MenuItem>
          <MenuItem value={"High"}>
            <div style={{ display: "flex", alignItems: "center" }}>
              <Warning style={{ color: "red" }} />
              <ListItemText primary="High Priority" />
            </div>
          </MenuItem>
        </Select>
      </FormControl>
    );
  }
}
