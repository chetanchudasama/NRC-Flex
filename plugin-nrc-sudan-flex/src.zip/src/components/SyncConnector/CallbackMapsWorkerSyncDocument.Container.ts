import { connect } from 'react-redux';
import { bindActionCreators, Dispatch } from 'redux';
import { AppState, namespace } from '../../states';
import { getMapKeys, getWorkerIdentity, getFlexToken } from '../../states/selectors';
import { addMapToStore, removeMapFromStore, setPlaySoundOnMapItemAdded } from '../../states/SyncMapState';
import { CallbackMapsWorkerSyncDocument } from "./CallbackMapsWorkerSyncDocument";

const mapStateToProps = (state: AppState) => ({
	currentMapKeys: getMapKeys(state),
	workerIdentity: getWorkerIdentity(state),
	flexAccessToken: getFlexToken(state),
	playSoundOnMapItemAdded: state[namespace].syncMap.config.playSoundOnMapItemAdded
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

const mapDispatchToProps = (dispatch: Dispatch<any>) => ({
	addMapToStore: bindActionCreators(addMapToStore, dispatch),
	removeMapFromStore: bindActionCreators(removeMapFromStore, dispatch),
	setPlaySoundOnMapItemAdded: bindActionCreators(setPlaySoundOnMapItemAdded, dispatch)
});
export type DispatchToProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(CallbackMapsWorkerSyncDocument);