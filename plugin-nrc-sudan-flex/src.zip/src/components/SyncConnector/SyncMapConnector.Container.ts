import { connect } from 'react-redux';
import { bindActionCreators, Dispatch } from 'redux';
import { addOrReplaceItemInStore, addOrReplaceItemsInStore, removeItemFromStore } from '../../states/SyncMapState';
import { SyncMapConnector } from './SyncMapConnector';

const mapDispatchToProps = (dispatch: Dispatch<any>) => ({
    addOrReplaceItemInStore: bindActionCreators(addOrReplaceItemInStore, dispatch),
    addOrReplaceItemsInStore: bindActionCreators(addOrReplaceItemsInStore, dispatch),
    removeItemFromStore: bindActionCreators(removeItemFromStore, dispatch)
});
export type DispatchToProps = ReturnType<typeof mapDispatchToProps>;

export default connect(null, mapDispatchToProps)(SyncMapConnector);