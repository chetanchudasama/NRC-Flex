import React from "react";
import { SyncClientActionsContext, SyncClientActionsContextProps } from "./SyncClientActionsContext";
import { StateToProps, DispatchToProps } from "./SyncClientConnector.Container";
import { SyncClient, SyncMap } from "twilio-sync";
import { ConnectionState } from "twilio-sync/lib/client";
import { Mutator } from "twilio-sync/lib/interfaces/mutator";
import { getSyncToken } from "../../api";
import SyncMapConnector from "./SyncMapConnector.Container";
import CallbackMapsWorkerSyncDocument from "./CallbackMapsWorkerSyncDocument.Container";
import { delayAsync } from "../../utils";

interface SyncClientConnectorOwnProps {
    children: React.ReactNode;
    showNotification: (type: 'warning' | 'error', message: string) => void;
    hideNotification: () => void;
}

type SyncClientConnectorProps = SyncClientConnectorOwnProps & StateToProps & DispatchToProps;

interface SyncClientConnectorState {
    status: 'connecting' | 'connected' | 'error';
}

const EVENT_CONNECTION_ERROR = "connectionError";
const EVENT_CONNECTION_STATE_CHANGED = "connectionStateChanged";
const EVENT_TOKEN_ABOUT_TO_EXPIRE = "tokenAboutToExpire";

export class SyncClientConnector extends React.Component<SyncClientConnectorProps, SyncClientConnectorState>{
    readonly state: Readonly<SyncClientConnectorState> = {
        status: "connecting"
    };

    private mounted: boolean = false;
    private client?: SyncClient;
    private mapRefs: SyncMap[] = [];

    private getMapForAction = async (mapId: string): Promise<SyncMap> => {
        let match = this.mapRefs.find(e => e.sid === mapId || e.uniqueName === mapId);
        if (match) { return match; }
        this.props.addMapToStore(mapId, false);
        await delayAsync(400);
        match = this.mapRefs.find(e => e.sid === mapId || e.uniqueName === mapId);
        if (match) { return match; }
        throw new Error(`map object with mapId: ${mapId} not found`);
    }

    private contextValue: SyncClientActionsContextProps = {
        syncClientActions: {
            removeMapItem: async (mapId: string, itemKey: string) => {
                const map = await this.getMapForAction(mapId);
                return map.remove(itemKey);
            },
            mutateMapItem: async (mapId: string, itemKey: string, mutatorFunction: Mutator, newTtl?: number) => {
                const map = await this.getMapForAction(mapId);
                return map.mutate(itemKey, mutatorFunction, newTtl ? { ttl: newTtl } : undefined);
            }
        }
    }

    constructor(props: SyncClientConnectorProps) {
        super(props);
        this.connectionErrorHandler = this.connectionErrorHandler.bind(this);
        this.connectionStateChanged = this.connectionStateChanged.bind(this);
        this.renewToken = this.renewToken.bind(this);
        this.setMapActionHandlers = this.setMapActionHandlers.bind(this);
        this.clearMapActionHandlers = this.clearMapActionHandlers.bind(this);
    }

    async componentDidMount() {
        this.mounted = true;

        const tokenRes = await getSyncToken(this.props.flexToken);
        if (tokenRes.error || !tokenRes.responseObj?.token) {
            if (this.mounted) {
                this.setState({
                    status: "error"
                });
                console.error(tokenRes.error || "failed to get sync token from API");
                this.props.showNotification("error", "failed to get sync token from API, please refresh the page to try again");
            }
            return;
        }

        //init client
        this.client = new SyncClient(tokenRes.responseObj.token);
        //set client event handlers
        this.client.on(EVENT_CONNECTION_ERROR, this.connectionErrorHandler);
        this.client.on(EVENT_CONNECTION_STATE_CHANGED, this.connectionStateChanged);
        this.client.on(EVENT_TOKEN_ABOUT_TO_EXPIRE, this.renewToken);
    }

    componentDidUpdate() {
        this.mapRefs = this.mapRefs
            .filter(e => this.props.requestedMapEntries
                .findIndex(([mapId, _]) => mapId === e.sid || mapId === e.uniqueName) !== -1);
    }

    componentWillUnmount() {
        this.mounted = false;
        //disable client handlers
        this.client?.off(EVENT_CONNECTION_ERROR, this.connectionErrorHandler);
        this.client?.off(EVENT_CONNECTION_STATE_CHANGED, this.connectionStateChanged);
        this.client?.off(EVENT_TOKEN_ABOUT_TO_EXPIRE, this.renewToken);
        //unassign objects
        this.client = undefined;
        this.mapRefs = [];
    }

    render() {
        switch (this.state.status) {
            case "connected":
                return <SyncClientActionsContext.Provider value={this.contextValue}>
                    {this.client ? <CallbackMapsWorkerSyncDocument
                        client={this.client}
                        showNotification={this.props.showNotification}
                    /> : null}
                    {this.props.requestedMapEntries?.map(([mapStoreItemId, mapStoreItemEntry]) => this.client ?
                        <SyncMapConnector key={`map-${mapStoreItemId}`}
                            mapId={mapStoreItemId}
                            client={this.client}
                            loadAndSyncItems={mapStoreItemEntry?.loadAndSyncItems || false}
                            setActionHandlers={this.setMapActionHandlers}
                            clearActionHandlers={this.clearMapActionHandlers} /> : null) || null}
                    {this.props.children}
                </SyncClientActionsContext.Provider>;
            default:
                return this.props.children;
        }
    }

    private setMapActionHandlers(map: SyncMap) {
        this.clearMapActionHandlers(map);
        this.mapRefs.push(map);
    }

    private clearMapActionHandlers(map: SyncMap) {
        this.mapRefs = this.mapRefs.filter(e => e.sid !== map.sid && e.uniqueName !== map.uniqueName);
    }

    private connectionErrorHandler(error: { terminal: boolean, message: string, httpStatusCode?: number, errorCode?: number }) {
        console.error("SyncClientConnector:connectionError");
        console.error(error.message || "terminal connection error occoured, please refresh the page to try again");
        if (this.mounted && error.terminal) {
            this.setState({
                status: "error"
            });
            this.props.showNotification("error", "terminal connection error occoured, please refresh the page to try again")
        }
    }

    private connectionStateChanged(connectionState: ConnectionState) {
        if (this.mounted) {
            switch (connectionState) {
                case "connecting":
                case "disconnecting":
                    this.setState({
                        status: "connecting"
                    });
                    this.props.showNotification("warning", "connecting to sync service, please wait ...");
                    break;
                case "connected":
                    this.setState({
                        status: "connected"
                    });
                    this.props.hideNotification();
                    break;
                default:
                    this.setState({
                        status: "error"
                    });
                    this.props.showNotification("error", `issue connecting to sync service, status is: ${connectionState}. please refresh the page to try again`);
            }
        }
    }

    private async renewToken() {
        const updateTokenRes = await getSyncToken(this.props.flexToken);
        if (updateTokenRes.responseObj?.token) {
            await this.client?.updateToken(updateTokenRes.responseObj?.token);
        }
    }
}