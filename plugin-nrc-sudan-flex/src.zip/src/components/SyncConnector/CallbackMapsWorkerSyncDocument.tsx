import React from "react";
import { StateToProps, DispatchToProps } from "./CallbackMapsWorkerSyncDocument.Container";
import { SyncClient, SyncDocument } from "twilio-sync";
import { initMapWorker } from "../../api";
interface CallbackMapsWorkerSyncDocumentOwnProps {
    client: SyncClient;
    showNotification: (type: 'warning' | 'error', message: string) => void;
}

type CallbackMapsWorkerSyncDocumentProps = CallbackMapsWorkerSyncDocumentOwnProps & StateToProps & DispatchToProps;

export class CallbackMapsWorkerSyncDocument extends React.PureComponent<CallbackMapsWorkerSyncDocumentProps> {

    private document?: SyncDocument;

    async componentDidMount() {
        await this.connectToDocument();
    }

    async componentDidUpdate() {
        if (this.document && this.document.uniqueName !== `CallbackMaps_${this.props.workerIdentity}`) {
            this.document.close();
            this.document = undefined;
            await this.connectToDocument();
        }
    }

    private async connectToDocument() {
        try {
            this.document = await this.props.client.document(`CallbackMaps_${this.props.workerIdentity}`);
            this.document.on("updated", (args: { value: any }) => {
                this.updateMaps(args.value?.callbackMapIds || [], true);

                const v = args.value?.config?.playSoundOnMapItemAdded ? true : false;
                if (v !== this.props.playSoundOnMapItemAdded) {
                    this.props.setPlaySoundOnMapItemAdded(v);
                } else {
                    console.warn("the same");
                    console.log(args);
                }
            });
            const docValueAsAny = (this.document.value as any);
            this.updateMaps(docValueAsAny?.callbackMapIds || []);
            if (docValueAsAny?.playSoundOnMapItemAdded !== this.props.playSoundOnMapItemAdded) {
                this.props.setPlaySoundOnMapItemAdded(docValueAsAny?.config?.playSoundOnMapItemAdded ? true : false);
            }
        } catch (err) {
            console.warn("failed to connect to callback maps worker sync document");
            const initRes = initMapWorker(this.props.flexAccessToken);
            if ((await initRes).statusCode === 201) {
                //retry, now doc has been created
                await this.connectToDocument();
                return;
            }
            console.error(err);
            this.props.showNotification("error", "failed to connect to callback maps document for worker, please refresh the page to try again");
        }
    }

    private updateMaps = (mapIdsToSync: string[], syncTriggered?: boolean) => {
        console.log(`updateMaps called @ ${new Date()}`);
        const currentMapKeys = this.props.currentMapKeys;
        mapIdsToSync.forEach(mapId => {
            const matchedIndex = currentMapKeys.findIndex(e => e === mapId);
            if (matchedIndex === -1) {
                //not found, call action to add
                this.props.addMapToStore(mapId, true);
            } else {
                //remove from array, as found
                currentMapKeys.splice(matchedIndex, 1);
            }
        });
        //items left in the array are in the store but not in the skills list, remove them
        if (currentMapKeys.length > 0) {
            currentMapKeys.forEach(mapIdToRemove => {
                this.props.removeMapFromStore(mapIdToRemove);
            });
        }
    }

    render() {
        return null; //non-visual component
    }
}