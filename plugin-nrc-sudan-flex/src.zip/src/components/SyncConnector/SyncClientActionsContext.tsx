import React from "react";
import { SyncMapItem } from "twilio-sync";
import { Mutator } from "twilio-sync/lib/interfaces/mutator";

export type SyncClientActionsContextProps = {
	syncClientActions?: {
		removeMapItem: (mapId: string, itemKey: string) => Promise<void>;
		mutateMapItem: (mapId: string, itemKey: string, mutatorFunction: Mutator, newTtl?: number) => Promise<SyncMapItem>;
	}
}

export const SyncClientActionsContext = React.createContext<SyncClientActionsContextProps>({});

export function withSyncClientActionsContext<C extends object>(WrappedComponent: React.ComponentType<C>): React.ComponentClass<C> {
	return class extends React.Component<C> {
		render() {
			return (
				<SyncClientActionsContext.Consumer>
					{context => {
						if (context === undefined) {
							throw new Error(`${WrappedComponent.displayName || "component"} wrapped in withSyncClientActionsContext must be used within a SyncClientActionsContext.Provider`);
						}
						return <WrappedComponent {...this.props} {...context} />;
					}}
				</SyncClientActionsContext.Consumer>
			);
		}
	}
}