import React from "react";
import { DispatchToProps } from "./SyncMapConnector.Container";
import { SyncClient, SyncMap, SyncMapItem } from "twilio-sync";
import { Paginator } from "twilio-sync/lib/paginator";

export interface SyncMapConnectorOwnProps {
    mapId: string;
    client: SyncClient;
    loadAndSyncItems: boolean;
    setActionHandlers: (map: SyncMap) => void;
    clearActionHandlers: (map: SyncMap) => void;
}

type SyncMapConnectorProps = SyncMapConnectorOwnProps & DispatchToProps;

const EVENT_ITEM_ADDED = "itemAdded";
const EVENT_ITEM_UPDATED = "itemUpdated";
const EVENT_ITEM_REMOVED = "itemRemoved";

export class SyncMapConnector extends React.Component<SyncMapConnectorProps>{

    private mounted: boolean = false;
    private map?: SyncMap;

    constructor(props: SyncMapConnectorProps) {
        super(props);
        this.itemAddedOrUpdated = this.itemAddedOrUpdated.bind(this);
        this.itemRemoved = this.itemRemoved.bind(this);
    }

    async componentDidMount() {
        this.mounted = true;
        await this.setupMap();
    }

    async componentDidUpdate(prevProps: SyncMapConnectorProps) {
        const mapIdChanged = prevProps.mapId !== this.props.mapId;
        console.log({prev: prevProps.mapId, new: this.props.mapId});
        const loadSettingChanged = prevProps.loadAndSyncItems !== this.props.loadAndSyncItems;
        if (mapIdChanged || loadSettingChanged) {
            await this.setupMap();
        }
    }

    componentWillUnmount() {
        this.mounted = false;
        this.removeMap();
    }

    render() {
        return null; //non visual component
    }

    private async setupMap() {
        if (this.map) {
            //clear existing
            this.removeMap();
        }
        try {
            //connect to map
            this.map = await this.props.client.map(this.props.mapId);

            //set map event handlers (if we want to load and sync data)
            if (this.props.loadAndSyncItems) {
                this.map.on(EVENT_ITEM_ADDED, this.itemAddedOrUpdated);
                this.map.on(EVENT_ITEM_UPDATED, this.itemAddedOrUpdated);
                this.map.on(EVENT_ITEM_REMOVED, this.itemRemoved);
            }

        } catch (err) {
            //failed to connect to map (bomb out)
            console.error(`error connecting to sync map with id: ${this.props.mapId}`);
            console.error(err);
            return;
        }

        //set pointer in parent for action handlers
        this.props.setActionHandlers(this.map);

        if (this.props.loadAndSyncItems) {
            //do intial load of data, (if requested)
            const mapId = this.props.mapId;
            try {
                await this.loadDataIntoStore(mapId, await this.map.getItems(), true);
            } catch (err) {
                console.error(`failed to load data for map: ${mapId}`);
                console.error(err);
            }
        }
    }

    private async loadDataIntoStore(mapId: string, paginator: Paginator<SyncMapItem>, clearExistingItems: boolean): Promise<void> {
        console.log(`IN LOAD DATA FOR MAP: ${mapId}, with page length: ${paginator.items.length} and next page: ${paginator.hasNextPage}`)
        if (!this.mounted || this.props.mapId !== mapId) {
            return;
        }

        //set page into store
        this.props.addOrReplaceItemsInStore(mapId, paginator.items.map(e => ({ ...e.value, id: e.key, lastUpdatedAt: e.dateUpdated })), clearExistingItems);

        // recurse arround until have all pages
        if (paginator.hasNextPage) {
            await this.loadDataIntoStore(mapId, await paginator.nextPage(), false);
        }
    }

    private removeMap() {
        if (this.map) {
            //clear pointer in parent for action handlers
            this.props.clearActionHandlers(this.map);
            //close conneciton (this removes event listeners for us)
            this.map.close();
            //unassign objects
            this.map = undefined;
        }
    }

    private itemAddedOrUpdated(event: { item: SyncMapItem, isLocal: boolean }) {
        if (this.mounted) {
            this.props.addOrReplaceItemInStore(this.props.mapId, { ...event.item.value, id: event.item.key, lastUpdatedAt: event.item.dateUpdated });
        }
    }

    private itemRemoved(event: { key: string, isLocal: boolean, value: unknown }) {
        if (this.mounted) {
            this.props.removeItemFromStore(this.props.mapId, event.key);
        }
    }
}