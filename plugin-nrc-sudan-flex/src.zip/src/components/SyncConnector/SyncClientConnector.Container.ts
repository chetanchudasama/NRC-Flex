import { bindActionCreators, Dispatch } from 'redux';
import { connect } from 'react-redux';
import { AppState } from '../../states';
import { getFlexToken, getMapEntries } from '../../states/selectors';
import { addMapToStore } from '../../states/SyncMapState';
import { SyncClientConnector } from './SyncClientConnector';

const mapStateToProps = (state: AppState) => ({
    flexToken: getFlexToken(state),
    requestedMapEntries: getMapEntries(state)
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

const mapDispatchToProps = (dispatch: Dispatch<any>) => ({
    addMapToStore: bindActionCreators(addMapToStore, dispatch),
});
export type DispatchToProps = ReturnType<typeof mapDispatchToProps>;

export default connect(mapStateToProps, mapDispatchToProps)(SyncClientConnector);