import { connect } from 'react-redux';
import { AppState } from '../../states';
import { getWorkerIsAvailable, getWorkerIdentity, getWorkerName, getFlexToken } from '../../states/selectors';
import { CallbackItemForm, CallbackItemFormOwnProps } from "./RecyclingTableItemForm";
import { withSyncClientActionsContext } from "../SyncConnector/SyncClientActionsContext";

const mapStateToProps = (state: AppState, props: CallbackItemFormOwnProps) => ({
    canMakeCall: getWorkerIsAvailable(state),
    workerIdentity: getWorkerIdentity(state),
    workerName: getWorkerName(state),
    flexAccessToken: getFlexToken(state)
});
export type StateToProps = ReturnType<typeof mapStateToProps>;

export default connect(mapStateToProps)(withSyncClientActionsContext(CallbackItemForm));