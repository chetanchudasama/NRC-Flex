import React from "react";
import styled from "react-emotion";
import { Actions, Icon, IconButton } from "@twilio/flex-ui";
import Grid from '@material-ui/core/Grid';
import Paper from "@material-ui/core/Paper";
import TextField from "@material-ui/core/TextField";
import { CallbackItem } from "../../models";
import { recycleCallback } from "../../api";
import { StateToProps } from "./RecyclingTableItemForm.Container";
import { RecycleIcon } from "../RecycleIcon";
import { SyncClientActionsContextProps } from "../SyncConnector/SyncClientActionsContext";
import { Typography } from "@material-ui/core";

const InlineIcon = styled(Icon)({
    display: "inline",
});

export interface CallbackItemFormOwnProps {
    item: CallbackItem;
}

type CallbackItemFormProps = StateToProps & CallbackItemFormOwnProps & SyncClientActionsContextProps;

export class CallbackItemForm extends React.PureComponent<CallbackItemFormProps> {

    private intervalId?: number;

    componentDidMount() {
        this.updateViewedAt();
        this.intervalId = window.setInterval(async () => await this.updateViewedAt(), 2000);
    }

    componentWillUnmount() {
        if (this.intervalId) {
            window.clearInterval(this.intervalId);
        }
    }

    private updateViewedAt = async () => {
        await this.props.syncClientActions?.mutateMapItem(this.props.item.mapId, this.props.item.mapItemId, (serverValue: any) => {
            const serverItem = serverValue;
            if (!Array.isArray(serverItem.viewers)) {
                serverItem.viewers = [];
            }
            const matchedIndex: number = serverItem.viewers.findIndex((e: any) => e.workerIdentity === this.props.workerIdentity);
            if (matchedIndex === -1) {
                serverItem.viewers.push({
                    workerIdentity: this.props.workerIdentity,
                    workerName: this.props.workerName,
                    lastActiveAtUtc: new Date().toISOString()
                });
            } else {
                serverItem.viewers[matchedIndex].workerName = this.props.workerName;
                serverItem.viewers[matchedIndex].lastActiveAtUtc = new Date().toISOString();
            }
            return serverItem;
        });
    };

    private recycleItem = async () => {
        await recycleCallback(this.props.flexAccessToken, this.props.item.mapId, this.props.item.mapItemId, this.props.item.phoneNumber);
    }

    private generateCurrentlyViewing = () => {
        const nowMinus4 = new Date();
        nowMinus4.setSeconds(nowMinus4.getSeconds() - 4);
        const fourSecondsAgo = nowMinus4.getTime();

        const names = this.props.item.viewers
            .filter(e => e.workerIdentity !== this.props.workerIdentity &&
                new Date(e.lastActiveAtUtc).getTime() > fourSecondsAgo)
            .reduce((res, e) => `${res}${res ? ", " : ""}${e.workerName}`, "");

        if (!names) {
            return null;
        }

        return (
            <Grid item xs={12}>
                <Paper elevation={0} style={{ width: "100%", marginBottom: "0.5rem", padding: "0.25rem", border: "0.15rem #64b5f6 solid" }}>
                    <InlineIcon icon="Agents" />
                    <span style={{ verticalAlign: "super" }}>Other Agents Viewing <span role="img" aria-label="eyes">👀</span>: {names}</span>
                </Paper>
            </Grid>
        );
    }

    render() {
        return (
            <Grid container style={{paddingTop: 10, paddingBottom: 10}} spacing={16}>
                {this.generateCurrentlyViewing()}
                <Grid item xs={3}>
                    <TextField
                        label="Phone Number"
                        value={this.props.item.phoneNumber}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    <TextField
                        label="Language"
                        value={this.props.item.language}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    <TextField
                        label="Location"
                        value={this.props.item.location}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    <TextField
                        label="Call Type"
                        value={this.props.item.callType}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    <TextField
                        label="Help Option"
                        value={this.props.item.helpOption}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    <TextField
                        label="Caller Type"
                        value={this.props.item.callerType}
                        disabled={true}
                    />
                </Grid>
                <Grid item xs={3}>
                    {this.props.item.noteUrl ?
                        <audio style={{ display: "block" }} controls={true} src={this.props.item.noteUrl} />
                        : <Typography variant="body1" style={{marginTop: "1rem", marginLeft: "1rem"}}>No Voicemail Left</Typography>}
                </Grid>
                <Grid item xs={3}>
                    <div style={{ float: "right", marginTop: "0.75rem" }}>
                        <IconButton title="Recycle Callback Item" icon={<RecycleIcon />} onClick={() => this.recycleItem()} />
                    </div>
                </Grid>
            </Grid>
        );
    }
}