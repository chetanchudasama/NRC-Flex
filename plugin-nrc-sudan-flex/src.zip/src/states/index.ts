import { AppState as FlexAppState } from '@twilio/flex-ui';
import { combineReducers } from 'redux';
import { SyncMapState, reduce as SyncMapReducer } from './SyncMapState';

// Register your redux store under a unique namespace
export const namespace = 'NRCSudan';
const syncMapSliceKey = "syncMap";

// Register all component states under the namespace
export interface AppState {
  flex: FlexAppState;
  [namespace]: {
    [syncMapSliceKey]: SyncMapState
  };
}

// Combine the reducers
export default combineReducers({
  [syncMapSliceKey]: SyncMapReducer
});
