import { AppState, namespace } from "./index";
import { createCachedSelector } from "re-reselect";
import { convertToCallbackItem } from "../models";

export const getWorkerIdentity = (state: AppState): string => state.flex.worker.attributes?.contact_uri.substr(7) || "";
export const getWorkerName = (state: AppState): string => state.flex.worker.attributes?.full_name || "";
export const getFlexToken = (state: AppState): string => state.flex.session.ssoTokenPayload.token;
export const getWorkerIsAvailable = (state: AppState): boolean => state.flex.worker.activity?.available ? true : false;

const getMaps = (state: AppState) => state[namespace].syncMap.maps;
export const getMapEntries = createCachedSelector(
	getMaps,
	(maps) => Object.entries(maps)
)((_) => "map-entries");

export const getMapKeys = createCachedSelector(
	getMaps,
	(maps) => Object.keys(maps)
)((_) => "map-keys");

export const getActiveCallbackItems = createCachedSelector(
	getMapEntries,
	(entries) => entries
		.flatMap(([mapId, mapStoreItemEntry]) => mapStoreItemEntry?.items?.filter(e => e.id !== "options")
			.map(e => convertToCallbackItem(mapId, e.id, e)) || [])
		.filter(e => !e.completed)
)((_) => "all-map-items");

export const getCompleteCallbackItems = createCachedSelector(
	getMapEntries,
	(entries) => entries
		.flatMap(([mapId, mapStoreItemEntry]) => mapStoreItemEntry?.items?.filter(e => e.id !== "options")
			.map(e => convertToCallbackItem(mapId, e.id, e)) || [])
		.filter(e => e.completed)
)((_) => "all-map-items");