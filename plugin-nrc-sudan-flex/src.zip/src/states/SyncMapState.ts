import { Actions } from "@twilio/flex-ui";
import { PluginActionNames } from "../constants";

//define state type for this slice and generate intial model
export type SyncMapState = {
	maps: Partial<Record<string, ISyncMapStateItem>>;
	config: { playSoundOnMapItemAdded: boolean };
}

export interface ISyncMapStateItem {
	items: ISyncMapItem[],
	loadAndSyncItems: boolean
}

export interface ISyncMapItem {
	id: string,
	lastUpdatedAt: Date
}

const initialState: SyncMapState = {
	maps: {},
	config: {
		playSoundOnMapItemAdded: false
	}
}

//export action creator functions to generate actions for this slice
export const addMapToStore = (mapId: string, loadAndSyncItems: boolean) => (<const>{ type: "SYNC_MAP_ADD_MAP", payload: { mapId, loadAndSyncItems } });
export const removeMapFromStore = (mapId: string) => (<const>{ type: "SYNC_MAP_REMOVE_MAP", payload: { mapId } });
export const addOrReplaceItemInStore = (mapId: string, item: ISyncMapItem) => (<const>{ type: "SYNC_MAP_ADD_OR_REPLACE_ITEM", payload: { mapId, item } });
export const addOrReplaceItemsInStore = (mapId: string, items: ISyncMapItem[], clearCurrent: boolean) => (<const>{ type: "SYNC_MAP_ADD_OR_REPLACE_ITEMS", payload: { mapId, items, clearCurrent } });
export const removeItemFromStore = (mapId: string, keyToRemove: string) => (<const>{ type: "SYNC_MAP_REMOVE_ITEM", payload: { mapId, keyToRemove } });
export const setPlaySoundOnMapItemAdded = (enable: boolean) => (<const>{ type: "SYNC_MAP_SET_CONFIG_PLAY_SOUND_ON_ITEM_ADD", payload: { enable } });

//create union of action types for this slice (with addtional flex action attribute)
type SyncMapActionTypes =
	ReturnType<typeof addMapToStore> |
	ReturnType<typeof removeMapFromStore> |
	ReturnType<typeof addOrReplaceItemInStore> |
	ReturnType<typeof addOrReplaceItemsInStore> |
	ReturnType<typeof removeItemFromStore> |
	ReturnType<typeof setPlaySoundOnMapItemAdded> |
	{ type: "" }; //for TS. need an action with no payload for combine reducers to not complain.

//export reducer for this slice
export function reduce(state: SyncMapState = initialState, action: SyncMapActionTypes): SyncMapState {
	switch (action.type) {
		case "SYNC_MAP_ADD_MAP":
			return {
				...state,
				maps: { ...state.maps, [action.payload.mapId]: { items: [...(state.maps[action.payload.mapId]?.items || [])], loadAndSyncItems: action.payload.loadAndSyncItems } }
			};
		case "SYNC_MAP_REMOVE_MAP":
			if (state.maps[action.payload.mapId] !== undefined) {
				const { [action.payload.mapId]: any, ...rest } = state.maps;
				return {
					...state,
					maps: rest
				};
			}
			return state;
		case "SYNC_MAP_ADD_OR_REPLACE_ITEM":
			return generateStateWithUpdatedItems(state, action.payload.mapId, [action.payload.item], false, state.config.playSoundOnMapItemAdded);
		case "SYNC_MAP_ADD_OR_REPLACE_ITEMS":
			return generateStateWithUpdatedItems(state, action.payload.mapId, action.payload.items, action.payload.clearCurrent, false);
		case "SYNC_MAP_REMOVE_ITEM":
			if (state.maps[action.payload.mapId] !== undefined) {
				return {
					...state,
					maps: {
						...state.maps, [action.payload.mapId]: {
							items: (state.maps[action.payload.mapId]?.items || []).filter(e => e.id !== action.payload.keyToRemove),
							loadAndSyncItems: state.maps[action.payload.mapId]?.loadAndSyncItems || false
						}
					}
				};
			}
			return state;
		case "SYNC_MAP_SET_CONFIG_PLAY_SOUND_ON_ITEM_ADD":
			return {
				...state,
				config: {
					...state.config,
					playSoundOnMapItemAdded: action.payload.enable
				}
			};
		default:
			return state;
	}
}

function generateStateWithUpdatedItems(state: SyncMapState, mapId: string, items: ISyncMapItem[], clearCurrent: boolean, emitPlaySoundAction: boolean): SyncMapState {
	const existingItem: ISyncMapStateItem = state.maps[mapId] || { items: [], loadAndSyncItems: false };

	const newItems = clearCurrent ? [] : [...existingItem.items];
	let newItemAdded: boolean = false;
	items.forEach(item => {
		const index = newItems.findIndex(e => e.id === item.id);
		if (index === -1) {
			newItems.push(item);
			newItemAdded = true;
		} else if (newItems[index].lastUpdatedAt < item.lastUpdatedAt) {
			newItems.splice(index, 1, item);
		}
	});

	if (newItemAdded && emitPlaySoundAction) {
		//only invoke if new item added (not for updates)
		Actions.invokeAction(PluginActionNames.PlayNewMapItemNotificationSound);
	}

	return {
		...state,
		maps: {
			...state.maps, [mapId]: {
				items: newItems,
				loadAndSyncItems: existingItem.loadAndSyncItems
			}
		}
	};
}