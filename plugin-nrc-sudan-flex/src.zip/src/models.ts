import { ITask } from "@twilio/flex-ui";
import { ConferenceState } from "@twilio/flex-ui/src/state/Conferences";
import { MD5 } from "crypto-js";

export interface CallbackMap {
  uniqueName: string;
  friendlyName?: string;
}

export class Worker {
  constructor(item: any) {
    this.sid = item.worker_sid || item.sid;
    if (typeof item.attributes === "string") {
      item.attributes = JSON.parse(item.attributes);
    }
    this.name = item?.attributes?.full_name || "";
    this.email = item?.attributes?.email || "";
    this.contact_uri = item?.attributes?.contact_uri || "";
    this.identity = this.contact_uri.substr(7) || "";
  }
  public readonly sid: string;
  public readonly name: string;
  public readonly email: string;
  public readonly contact_uri: string;
  public readonly identity: string;
}

export interface OutboundCallTaskInfo {
  taskSid: string;
  toNumber: string;
  conferenceSid: string;
  conferenceCallSids: string[];
  workerIdentity: string;
  workerName: string;
  createdAtUtc: string;
}

interface Viewer {
  workerIdentity: string;
  workerName: string;
  lastActiveAtUtc: string;
}

export interface CallbackItem {
  mapId: string;
  mapItemId: string;
  initialCallDate: string;
  expiryDate: string;
  phoneNumber: string;
  callerId: string;
  attempts: number;
  language: string;
  location: string;
  isComplaint: boolean;
  callType: string;
  callerType: string;
  helpOption: string;
  noteUrl: string;
  priority: string;
  completed: boolean;
  completedBy: string;
  completedAt: string;
  callbackHistory?: OutboundCallTaskInfo[];
  viewers: Viewer[];
  notifiedWorkers: string[];
}

export const convertToCallbackItem = (
  mapId: string,
  mapItemId: string,
  value?: object
): CallbackItem => {
  const item = value as any;
  return {
    mapId,
    mapItemId,
    initialCallDate: item?.initialCallDate || "",
    expiryDate: item?.expiryDate || "",
    phoneNumber: item?.phoneNumber || "",
    callerId: item?.callerId || "",
    attempts: typeof item?.attempts === "number" ? item?.attempts : 0,
    language: item?.language || "",
    location: item?.location || "",
    isComplaint: item?.isComplaint,
    callType: item?.isComplaint ? "Feedback/ Complaint" : "Help Request",
    callerType: item?.callerType || "",
    helpOption: item?.helpOption || "",
    noteUrl: item?.noteUrl || "",
    priority: item?.priority || "",
    completed: item?.completed ? true : false,
    completedBy: item?.completedBy || "",
    completedAt: item?.completedAt || "",
    callbackHistory: item?.callbackHistory || [],
    viewers: item?.viewers || [],
    notifiedWorkers: item?.notifiedWorkers || [],
  };
};

export const getOutboundCallTaskInfoWithHash = (
  workerIdentity: string,
  workerName: string,
  task?: ITask,
  conference?: ConferenceState
): [string, OutboundCallTaskInfo] | null => {
  if (task && task.channelType === "voice") {
    const a = task.attributes as any;
    if (a.direction === "outbound" && a.outbound_to) {
      const info: OutboundCallTaskInfo = {
        taskSid: task.taskSid,
        toNumber: a.outbound_to,
        conferenceSid: conference?.source.conferenceSid || "",
        conferenceCallSids:
          conference?.source.participants.map((e) => e.callSid) || [],
        workerIdentity: workerIdentity,
        workerName,
        createdAtUtc: task.dateCreated.toISOString(),
      };

      if (info.conferenceCallSids.length > 0) {
        //NOTE: only return result if at least one leg connected
        const hash = MD5(JSON.stringify(info)).toString();
        return [hash, info];
      }
    }
  }
  return null;
};
