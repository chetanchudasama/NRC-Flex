# NRC Sudan Flex Plugin

The NRC Sudan flex implementation main features:

- Callback table
- Listening to voicemails inside the callback table (Audio Player)
- Skills of workers specific to Language and Region

The Studio flow ( [Link]() ) is a "FAQ" Studio flow, so the incoming calls should be in reference to a specific question.



## Setup

Make sure you have [Node.js](https://nodejs.org) as well as [`npm`](https://npmjs.com). We support Node >= 10.12 (and recommend the _even_ versions of Node). Afterwards, install the dependencies by running `npm install`:

```bash
cd 

# If you use npm
npm install
```

Next, please install the [Twilio CLI](https://www.twilio.com/docs/twilio-cli/quickstart) by running:

```bash
brew tap twilio/brew && brew install twilio
```

Finally, install the [Flex Plugin extension](https://github.com/twilio-labs/plugin-flex/tree/v1-beta) for the Twilio CLI:

```bash
twilio plugins:install @twilio-labs/plugin-flex@beta
```

## Development

To Run the Flex plugin, make sure you are logged into the NRC Sudan Twilio Account

```bash
# Make sure you have the Account SID and Auth Token from the Twilio Console
twilio login

# Once you have logged into the Sudan Account, be sure to use that profile
twilio profiles:use <YOUR NRC SUDAN ACCOUNT>
```

